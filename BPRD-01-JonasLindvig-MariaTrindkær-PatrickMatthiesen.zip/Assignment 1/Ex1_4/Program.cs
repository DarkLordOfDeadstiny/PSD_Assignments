﻿
using Ex1_4;


Expr e = new Add(new CstI(17), new Var("z"));
Console.WriteLine(e.ToString());

