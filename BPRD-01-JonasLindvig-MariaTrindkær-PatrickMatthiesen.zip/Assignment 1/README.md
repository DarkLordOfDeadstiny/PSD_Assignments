# Assingment 1 - Jonas Lindvig, Maria Torp Trindkær og Patrick Bohn Matthiesen

## 1.1

This exercise can be found in PSD_As1/Intro2.fs

## 1.2

This exercise can be found in PSD_As1/Intro2.fs

## 1.4

This exercise can be found in Ex1_4/Ex1_4.cs

## 2.1

This exercise can be found in PSD_As1/Intcomp1.fs

## 2.2

This exercise can be found in PSD_As1/Intcomp1.fs

## 2.3

This exercise can be found in PSD_As1/Intcomp1.fs
