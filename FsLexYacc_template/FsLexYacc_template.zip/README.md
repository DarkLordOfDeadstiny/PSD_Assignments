# FsLexYacc Template

This is a Template for the assignments in PRDAT. It will allow you to compile the `.fsy` and `.fsl` using `dotnet build` in the console. Most IDE builders might not work as they use specialized build commands.

How to set it up:

1. Change name of the folder to whatever you want (maybe the assignment name).

2. Change name of `.sln` to the same as the folder name.
3. Change name of the project folder (the one next to the `.sln` file).
4. Change name of the `.csproj` file.
5. Replace the `.fsy` and `.fsl` with your own.
6. Update the file names in the `.csproj`. Make sure to update the module name too.

    ```csproj
    <FsYacc Include="CPar.fsy">
        <OtherFlags>--module CPar</OtherFlags>
    </FsYacc>
    <FsLex Include="CLex.fsl">
        <OtherFlags>--unicode</OtherFlags>
    </FsLex>
    ```

7. Run `dotnet restore`
8. Run `dotnet build` every time you change your `.fsy` and `.fsl` files.
